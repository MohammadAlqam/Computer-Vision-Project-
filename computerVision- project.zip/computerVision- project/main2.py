import cv2
import numpy as np

#import image
image = cv2.imread('book1_page11.png')
cv2.imwrite("C:\\Users\\Mohammad Alqam\\OneDrive\\Desktop\\computerVision-1rst project\\original image.png",image)


#grayscale
gray = cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
cv2.imwrite("C:\\Users\\Mohammad Alqam\\OneDrive\\Desktop\\computerVision-1rst project\\gray.png",gray)


#threshold image
ret,thresh = cv2.threshold(gray,127,255,cv2.THRESH_BINARY_INV)
cv2.imwrite("C:\\Users\\Mohammad Alqam\\OneDrive\\Desktop\\computerVision-1rst project\\thresh.png",thresh)


#erosion image
kernel = np.ones((1,6),np.uint8)
erosion = cv2.erode(thresh,kernel,iterations = 2)
cv2.imwrite("C:\\Users\\Mohammad Alqam\\OneDrive\\Desktop\\computerVision-1rst project\\erosion.png",erosion)

#dilation image
kernal= cv2.getStructuringElement(cv2.MORPH_RECT,(25,3))
imgd=cv2.morphologyEx(erosion,cv2.MORPH_CLOSE,kernal,iterations = 4)
cv2.imwrite("C:\\Users\\Mohammad Alqam\\OneDrive\\Desktop\\computerVision-1rst project\\dilation.png",imgd)

#blur image
blur=cv2.blur(imgd,(25,3),0)
ret,threshblur = cv2.threshold(blur,1,255,cv2.THRESH_BINARY)
cv2.imwrite("C:\\Users\\Mohammad Alqam\\OneDrive\\Desktop\\computerVision-1rst project\\blur.png",threshblur)









#split lines

pts = cv2.findNonZero(imgd)
ret = cv2.minAreaRect(pts)

(cx,cy), (w,h), ang = ret
if w>h:
    w,h = h,w
    ang += 90

## Find rotated matrix, do rotation
M = cv2.getRotationMatrix2D((cx,cy), ang, 1.0)
rotated = cv2.warpAffine(imgd, M, (image.shape[1], image.shape[0]))

## find and draw the upper and lower boundary of each lines
hist = cv2.reduce(rotated,1, cv2.REDUCE_AVG).reshape(-1)

th = 2
H,W = image.shape[:2]
uppers = [y for y in range(H-1) if hist[y]<=th and hist[y+1]>th]
lowers = [y for y in range(H-1) if hist[y]>th and hist[y+1]<=th]

rotated = cv2.cvtColor(rotated, cv2.COLOR_GRAY2BGR)
for y in uppers:
    cv2.line(image, (0,y), (W, y), (255,0,0), 1)

for y in lowers:
    cv2.line(image, (0,y), (W, y), (0,255,0), 1)


cv2.imwrite("C:\\Users\\Mohammad Alqam\\OneDrive\\Desktop\\computerVision-1rst project\\lines.png",image)




#contouring image

edge = cv2.Canny(thresh, 100, 200)
(cnts, _) = cv2.findContours(edge.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)


total = 0
for c in cnts:
    epsilon = 0.0008 * cv2.arcLength(c, True)
    approx = cv2.approxPolyDP(c, epsilon, True)

    cv2.drawContours(rotated, [approx], -1, (0, 255, 0), 4)
    total += 1

print ("I found {0} RET in that image".format(total))
cv2.imwrite("C:\\Users\\Mohammad Alqam\\OneDrive\\Desktop\\computerVision-1rst project\\contour.png", rotated)




#output image
_, thresh=cv2.connectedComponents(imgd)

#get clone of binary image to work on so that finally we can compare input and output images
binaryImageClone = np.copy(thresh)

#Find the max and min pixel values and their locations
(minValue, maxValue, minPosition, maxPosition) = cv2.minMaxLoc(binaryImageClone)

#normalize the image so that the min value is 0 and max value is 255
binaryImageClone = 255 * (binaryImageClone - minValue) / (maxValue - minValue)

#convert image to 8bits unsigned type
binaryImageClone = np.uint8(binaryImageClone)

#Apply a color map
binaryImageCloneColorMap = cv2.applyColorMap(binaryImageClone, cv2.COLORMAP_JET)
#cimg=cv2.copyTo(binaryImageCloneColorMap,"C:\\Users\\Mohammad Alqam\\OneDrive\\Desktop\\computerVision-1rst project")
nn=cv2.add(binaryImageCloneColorMap,image)


cv2.imwrite("C:\\Users\\Mohammad Alqam\\OneDrive\\Desktop\\computerVision-1rst project\\color.png", nn)
cv2.imwrite("C:\\Users\\Mohammad Alqam\\OneDrive\\Desktop\\computerVision-1rst project\\color2.png", binaryImageCloneColorMap)











